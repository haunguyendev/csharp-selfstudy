﻿namespace PRNslot3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnTinh_Click(object sender, EventArgs e)
        {
            var num1 = Convert.ToDouble(textNum1.Text);
            var num2 = Convert.ToDouble(textNum2.Text);
            var result = "";
            if (cbCong.Checked)
            {
                result += "Cộng: " + (num1 + num2) + "\n";
            }
            if (cbTru.Checked)
            {
                result += "Trừ: " + (num1 - num2) + "\n";
            }
            if (cbNhan.Checked)
            {
                result += "Nhân: " + (num1 * num2) + "\n";
            }
            if (cbChia.Checked)
            {
                if (num2 == 0)
                {
                    result += "Số chia phải khác 0.";
                }
                else
                {
                    result += "Chia :" + (num1 / num2);
                }
            }
            lbResult.Text = result;
            lbResult.Visible = true;




        }
    }
}